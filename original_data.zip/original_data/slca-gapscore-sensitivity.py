"""
Combined 2x2 grid: base gap-score chart (top-left) plus the three
sensitivity scenarios, sharing the same x-axis (0-10), threshold
lines, and colour scale so all four panels are directly comparable.

Font sizes are controlled by the FONT_SIZE variable below — change
that one number and every label (axis ticks, panel titles, threshold
labels, bar annotations) scales with it.

Note on error bars: some source files have "Max gap score" numerically
SMALLER than "Min gap score" for a given row (columns are mislabeled/
swapped upstream). This script does not trust the column names — it
takes min(Max, Min) as the lower bound and max(Max, Min) as the upper
bound for each row. Error bars shown are +/- 1 estimated SD, computed
as range / 4 (a rough approximation; no sample size is given in the
source files to compute a real SD).
"""

import openpyxl
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np

# ==== USER CONTROLS ====
# Tweak these to taste — every label in the figure pulls from one of
# these five settings.
TITLE_FONT_SIZE = 16
AXIS_LABEL_FONT_SIZE = 16   # "Gap Score" x-axis label
TICK_FONT_SIZE = 14          # hotspot names + numeric axis ticks
THRESHOLD_FONT_SIZE = 14     # Low/Monitor/Moderate/High/Critical labels
ANNOTATION_FONT_SIZE = 10    # explanation text beside each bar

YLABEL_ROTATION = 45        # degrees; 0 = horizontal, 90 = vertical

# Shorter labels for the y-axis. Key = exact "SHDB Hotspot" text from
# the spreadsheet, value = whatever short label you want shown on the
# chart instead. Any hotspot left out of this dict falls back to its
# full spreadsheet label.
SHORT_YLABELS = {
    "1D (Child Labor)": "1D:Child Labor",
    "1F (Excessive WkTime)": "1F:Excess Work",
    "1G (Freedom of Assoc)": "1G:Freedom Assoc",
    "1H (Migrant Labor)": "1H:Migrant Labor",
    "1I (Social Benefits)": "1I:Social Ben",
    "1K (Discrimination)": "1K:Discrimin",
    "2A (Occupational Toxicity and Hazard)": "2A:Occ Tox Haz",
    "2B (Injuries & Fatalities)": "2B:Inj Fatal",
    "3C (High Conflict Zones)": "3C:High Confl",
    "3F (Poverty and Inequality)": "3F:Pov & Ineq",
    "3G (State of Env. Sustainability)": "3G:State of Env",
    "4A (Legal System)": "4A:Legal Sys",
    "4C (Democracy & Freedom of Speech)": "4C:Democracy",
    "5B (Access to Sanitation)": "5B:Acc Sanitation",
    "5D (Access to Hospital Beds)": "5D:Acc Hosp Beds",
    "5G (Property Rights)": "5G:Prop Rights",
}

FILES = [
    ("gap-score-base.xlsx", "(a) Base: 33%S&C - 33%En - 33%I&M"),
    ("gap-score-sensitivity1.xlsx", "(b) Sen 1: 60%S&C - 20%En - 20%I&M"),
    ("gap-score-sensitivity2.xlsx", "(c) Sen 2: 20%S&C - 60%En - 20%I&M"),
    ("gap-score-sensitivity3.xlsx", "(d) Sen 3: 20%S&C - 20%En - 60%I&M"),
]

THRESHOLDS = {
    "Low": 0,
    "Monitor": 1,
    "Moderate": 2,
    "High": 3,
    "Critical": 5,
}

CMAP = mcolors.LinearSegmentedColormap.from_list(
    "priority",
    [(0 / 1, "green"), (2 / 5, "grey"), (1.0, "red")],
)


def load_sheet(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["Sheet1"]
    rows = list(ws.iter_rows(values_only=True))
    header, data_rows = rows[0], rows[1:]

    labels = [r[0] for r in data_rows]
    means = np.array([r[1] for r in data_rows], dtype=float)
    col_max = np.array([r[2] for r in data_rows], dtype=float)
    col_min = np.array([r[3] for r in data_rows], dtype=float)

    if len(header) >= 5 and data_rows and len(data_rows[0]) >= 5:
        annotations = [r[4] if r[4] is not None else "" for r in data_rows]
    else:
        annotations = ["" for _ in data_rows]

    lower_bound = np.minimum(col_max, col_min)
    upper_bound = np.maximum(col_max, col_min)
    range_ = upper_bound - lower_bound
    sd_est = range_ / 4.0

    err_low = np.minimum(sd_est, means)
    err_high = sd_est
    xerr = np.vstack([err_low, err_high])

    return labels, means, xerr, annotations


def plot_panel(ax, labels, means, xerr, annotations, title, show_ylabels, show_xlabel):
    labels_plot = labels[::-1]
    means_plot = means[::-1]
    xerr_plot = xerr[:, ::-1]
    annotations_plot = annotations[::-1]

    y_pos = np.arange(len(labels_plot))
    norm_x = np.clip(means_plot, 0, 5) / 5.0
    bar_colors = CMAP(norm_x)

    ax.barh(
        y_pos, means_plot,
        xerr=xerr_plot,
        color=bar_colors,
        ecolor="black",
        capsize=3,
        error_kw={"elinewidth": 1, "capthick": 1},
    )

    bar_end_plot = means_plot + xerr_plot[1]
    for y, note, x_end in zip(y_pos, annotations_plot, bar_end_plot):
        if note:
            ax.text(
                x_end + 0.15, y, note,
                ha="left", va="center",
                fontsize=ANNOTATION_FONT_SIZE, color="black",
            )

    ax.set_yticks(y_pos)
    short_labels_plot = [SHORT_YLABELS.get(lab, lab) for lab in labels_plot]
    ax.set_yticklabels(
        short_labels_plot, fontsize=TICK_FONT_SIZE,
        rotation=YLABEL_ROTATION, ha="right",
        rotation_mode="anchor",
    )
    if not show_ylabels:
        ax.tick_params(axis="y", labelleft=False)
    ax.set_xlim(0, 8)
    if show_xlabel:
        ax.set_xlabel("Gap Score", fontsize=AXIS_LABEL_FONT_SIZE)
    ax.tick_params(axis="x", labelsize=TICK_FONT_SIZE)
    ax.set_title(title, fontsize=TITLE_FONT_SIZE, fontweight="bold", pad=26)

    for name, x in THRESHOLDS.items():
        ax.axvline(
            x=x, color="lightgray", linewidth=1.3, linestyle="--",
            alpha=0.99, zorder=0,
        )
        ax.text(
            x, len(labels_plot) - 0.3, name,
            rotation=45, ha="left", va="bottom",
            fontsize=THRESHOLD_FONT_SIZE, fontweight="bold",
        )

    ax.set_ylim(-0.5, len(labels_plot) + 1.0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


# ---- Build 2x2 panel figure ----
n_rows_ref = None
fig, axes = plt.subplots(
    2, 2, figsize=(16, 18), sharex=True, sharey=True,
)
axes_flat = axes.flatten()

for i, ((path, title), ax) in enumerate(zip(FILES, axes_flat)):
    labels, means, xerr, annotations = load_sheet(path)
    if n_rows_ref is None:
        n_rows_ref = len(labels)
    elif len(labels) != n_rows_ref:
        raise ValueError(
            f"{path} has {len(labels)} hotspot rows, expected {n_rows_ref}. "
            "Panels must share the same categories to be comparable."
        )
    row, col = divmod(i, 2)
    # With shared x/y axes, only the left column needs category labels
    # and only the bottom row needs the "Gap Score" x-axis label.
    plot_panel(
        ax, labels, means, xerr, annotations, title,
        show_ylabels=(col == 0),
        show_xlabel=(row == 1),
    )

plt.tight_layout()
plt.subplots_adjust(wspace=0.02, hspace=0.15, left=0.05)
plt.savefig("gap_score_combined.png", dpi=400, bbox_inches="tight")
print("Saved.")