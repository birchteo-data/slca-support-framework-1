import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.gridspec import GridSpec


# =============================================================================
# FILES
# =============================================================================

FILES = [
    ("SHDB_hotspots.csv", "(a) REI"),
    ("SHDB_hotspots_SnC.csv", "(b) Scope and Coverage"),
    ("SHDB_hotspots_En.csv", "(c) Enforcement"),
    ("SHDB_hotspots_InM.csv", "(d) Implementation and Monitoring"),
]


# =============================================================================
# CUSTOMISABLE COLOURS
# =============================================================================

# LOW    = RED
# MIDDLE = LIGHT GREY
# HIGH   = GREEN

LOW_COLOUR = "#D73027"
MID_COLOUR = "#D9D9D9"
HIGH_COLOUR = "#1A9850"


# =============================================================================
# COLOUR MAP
# =============================================================================

cmap = LinearSegmentedColormap.from_list(
    "RedGreyGreen",
    [
        (0.00, LOW_COLOUR),
        (0.50, MID_COLOUR),
        (1.00, HIGH_COLOUR),
    ]
)

cmap.set_bad(color="white")


# =============================================================================
# LABEL STANDARDISATION
# =============================================================================

LABEL_MAP = {
    "3C High Conflict Zones": "3C (High Conflict Zones)",
    "4A Legal System": "4A (Legal System)",
}


def load_panel(path):

    df = pd.read_csv(
        path,
        index_col=0
    )

    # -------------------------------------------------------------------------
    # Standardise labels
    # -------------------------------------------------------------------------

    df.index = [
        LABEL_MAP.get(
            str(i),
            str(i)
        )
        for i in df.index
    ]

    # -------------------------------------------------------------------------
    # Keep hotspot code only
    # -------------------------------------------------------------------------

    df.index = [
        str(i).split()[0]
        for i in df.index
    ]

    # -------------------------------------------------------------------------
    # Combine duplicate hotspot codes
    # -------------------------------------------------------------------------

    df = df.groupby(
        level=0
    ).max()

    return df


# =============================================================================
# LOAD DATA
# =============================================================================

panels = [
    load_panel(path)
    for path, _ in FILES
]

titles = [
    title
    for _, title in FILES
]


# =============================================================================
# CREATE MASTER HOTSPOT LIST
# =============================================================================

row_order = []

for panel in panels:

    for row in panel.index:

        if row not in row_order:

            row_order.append(row)


# =============================================================================
# NATURAL SORTING
# =============================================================================

def hotspot_sort_key(code):

    code = str(code)

    number = ""
    letters = ""

    for char in code:

        if char.isdigit():

            number += char

        else:

            letters += char

    try:

        number = int(number)

    except ValueError:

        number = 999

    return (
        number,
        letters
    )


row_order = sorted(
    row_order,
    key=hotspot_sort_key
)


# =============================================================================
# COLUMN ORDER
# =============================================================================

col_order = list(
    panels[1].columns
)


# =============================================================================
# REINDEX ALL PANELS
# =============================================================================

panels = [
    p.reindex(
        index=row_order,
        columns=col_order
    )
    for p in panels
]


# =============================================================================
# SCORE RANGE
# =============================================================================

score_panels = panels[1:]

score_vmin = 1

score_vmax = max(
    np.nanmax(
        p.values.astype(float)
    )
    for p in score_panels
)


# =============================================================================
# SHDB HOTSPOT DESCRIPTIONS
# =============================================================================

HOTSPOT_DESCRIPTIONS = {

    "1D": "Child Labor",
    "1F": "Excessive WkTime",
    "1G": "Freedom of Assoc",
    "1H": "Migrant Labor",
    "1I": "Social Benefits",
    "1K": "Discrimination",
    "1L": "Unemployment",

    "2A": "Occupational Toxicity and Hazard",
    "2B": "Injuries & Fatalities",

    "3C": "High Conflict Zones",
    "3F": "Poverty and Inequality",
    "3G": "State of Env. Sustainability",

    "4A": "Legal System",
    "4C": "Democracy & Freedom of Speech",

    "5B": "Access to Sanitation",
    "5D": "Access to Hospital Beds",
    "5G": "Property Rights",
}


# =============================================================================
# REGULATORY FRAMEWORK
# =============================================================================

REGULATORY_DESCRIPTIONS = {

    # -------------------------------------------------------------------------
    # A — AGRICULTURE
    # -------------------------------------------------------------------------

    "A1":
        "Nitrates Directive (91/676/EEC)",

    "A2":
        "EU Good Agricultural Practice for Protection of Waters (GAP) Regulations 2025",

    "A3":
        "EU Common Agricultural Policy (CAP) Conditionality Requirements 2021/2115 – attached to subsidy eligibility",

    "A4":
        "European Communities – Sustainable Use of Pesticides – Regulations 2012",


    # -------------------------------------------------------------------------
    # B — FORESTRY
    # -------------------------------------------------------------------------

    "B1":
        "Forestry Act 2014",

    "B2":
        "Forestry Regulations 2017",

    "B3":
        "EU Environmental Impact Assessment (EIA) Directive 2011/92/EU, as amended by 2014/52/EU",

    "B4":
        "Conservation of Wild Birds Directive 2009/147/EC",


    # -------------------------------------------------------------------------
    # C — FISHERIES / MARINE
    # -------------------------------------------------------------------------

    "C1":
        "EU Common Fisheries Policy (CFP) 1380/2013",

    "C2":
        "EU Marine Strategy Framework Directive (MSFD)",

    "C3":
        "Maritime Labour Convention (MLC) 2006",


    # -------------------------------------------------------------------------
    # D — WASTE
    # -------------------------------------------------------------------------

    "D1":
        "Waste Framework Directive 2008/98/EC, as amended by 2018/851/EU",

    "D2":
        "Waste Management Act 1996 / Revised in 2026",

    "D3":
        "EU Industrial Emissions Directive 2010 and Irish Regulations 2013",

    "D4":
        "Waste Water Discharge – Authorisation – Regulations 2007",

    "D5":
        "Urban Wastewater – Nutrient-Sensitive Areas – Regulations 2025",


    # -------------------------------------------------------------------------
    # E — ENERGY / CLIMATE
    # -------------------------------------------------------------------------

    "E1":
        "Renewable Energy Directive III (EU) 2023/2413",

    "E2":
        "Governance of the Energy Union Regulation (EU) 2018/1999",

    "E3":
        "EU Emissions Trading System Directive 2003/87/EC (as amended)",

    "E4":
        "Climate Action and Low Carbon Development Act 2015 (amended 2021)",

    "E5":
        "Renewable Electricity Support Scheme (RESS) – Ireland",

    "E6":
        "National Biomethane Strategy – Ireland",


    # -------------------------------------------------------------------------
    # F — SOCIAL / LABOUR
    # -------------------------------------------------------------------------

    "F1":
        "Safety, Health and Welfare at Work Act 2005",

    "F2":
        "EU Corporate Sustainability Reporting Directive (CSRD) 2022/2464",

    "F3":
        "European Sustainability Reporting Standards (ESRS) S1–S4",

    "F4":
        "EU Corporate Sustainability Due Diligence and Amending Directive (CSDDD) 2024/1760, substantially amended by Omnibus I 2026/470",

    "F5":
        "International Labour Conventions and Recommendations 2015 (C87, C98, C138, C182)",
}


# =============================================================================
# FIGURE DIMENSIONS
# =============================================================================

n_rows = len(row_order)

ROW_HEIGHT = 0.58

FIG_WIDTH = 13

# Height required for heatmaps
HEATMAP_HEIGHT = max(
    9.5,
    ROW_HEIGHT * n_rows + 2.5
)

# Compact table height
TABLE_HEIGHT = 3.8

FIG_HEIGHT = (
    HEATMAP_HEIGHT +
    TABLE_HEIGHT
)


print()
print("=" * 70)
print("HOTSPOT CATEGORIES FOUND")
print("=" * 70)

for i, row in enumerate(
    row_order,
    start=1
):

    print(
        f"{i:2d}. {row}"
    )

print("=" * 70)
print(
    f"Number of hotspot rows: {n_rows}"
)
print(
    f"Figure size: {FIG_WIDTH} x {FIG_HEIGHT}"
)
print("=" * 70)
print()


# =============================================================================
# CREATE FIGURE
# =============================================================================

fig = plt.figure(
    figsize=(
        FIG_WIDTH,
        FIG_HEIGHT
    )
)


# =============================================================================
# GRID SPECIFICATION
# =============================================================================
#
# IMPORTANT:
#
# The table is now part of the GridSpec.
#
# This eliminates the large white area that occurred when the table was
# positioned manually with fig.add_axes().
#
# =============================================================================

gs = GridSpec(
    3,
    2,
    figure=fig,

    # Two heatmap rows + compact table
    height_ratios=[
        1,
        1,
        0.48
    ],

    # Very small vertical gap
    hspace=0.10,

    # Small horizontal gap
    wspace=0.06,

    left=0.12,
    right=0.96,
    top=0.975,
    bottom=0.025
)


# =============================================================================
# CREATE HEATMAP AXES
# =============================================================================

axes = np.array([

    fig.add_subplot(
        gs[0, 0]
    ),

    fig.add_subplot(
        gs[0, 1]
    ),

    fig.add_subplot(
        gs[1, 0]
    ),

    fig.add_subplot(
        gs[1, 1]
    )

])


# =============================================================================
# SEVERITY IMAGE
# =============================================================================

score_image = None


# =============================================================================
# PLOT HEATMAPS
# =============================================================================

for panel_number in range(4):

    ax = axes[panel_number]

    panel = panels[panel_number]

    title = titles[panel_number]

    is_rei = (
        panel_number == 0
    )


    # -------------------------------------------------------------------------
    # DATA
    # -------------------------------------------------------------------------

    data = panel.values.astype(float)

    masked_data = np.ma.masked_invalid(
        data
    )


    # =========================================================================
    # NORMALISATION
    # =========================================================================

    if is_rei:

        norm = TwoSlopeNorm(
            vmin=0,
            vcenter=0.5,
            vmax=1
        )

    else:

        norm = TwoSlopeNorm(
            vmin=score_vmin,
            vcenter=2,
            vmax=score_vmax
        )


    # =========================================================================
    # HEATMAP
    # =========================================================================

    im = ax.imshow(
        masked_data,
        cmap=cmap,
        norm=norm,
        aspect="auto",
        interpolation="nearest"
    )


    if (
        not is_rei
        and score_image is None
    ):

        score_image = im


    # =========================================================================
    # X AXIS
    # =========================================================================

    ax.set_xticks(
        np.arange(
            len(col_order)
        )
    )

    ax.set_xticklabels(
        col_order,
        rotation=90,
        ha="center",
        fontsize=10
    )


    # =========================================================================
    # Y AXIS
    # =========================================================================

    y_positions = np.arange(
        len(row_order)
    )

    ax.set_yticks(
        y_positions
    )


    # Only left column displays hotspot codes
    if panel_number in [0, 2]:

        ax.set_yticklabels(
            row_order,
            fontsize=10,
            rotation=0,
            ha="right"
        )

        ax.tick_params(
            axis="y",
            which="major",
            labelleft=True,
            left=True,
            length=3,
            pad=4
        )

    else:

        ax.set_yticklabels([])

        ax.tick_params(
            axis="y",
            which="major",
            labelleft=False,
            left=False
        )


    # =========================================================================
    # CELL VALUES
    # =========================================================================

    for i in range(
        data.shape[0]
    ):

        for j in range(
            data.shape[1]
        ):

            value = data[i, j]

            if np.isnan(value):

                continue


            # -----------------------------------------------------------------
            # FORMAT
            # -----------------------------------------------------------------

            if is_rei:

                text = f"{value:.1f}"

                distance = (
                    abs(value - 0.5) / 0.5
                )

            else:

                text = f"{value:.0f}"

                distance = abs(
                    value - 2
                )


            # -----------------------------------------------------------------
            # TEXT COLOUR
            # -----------------------------------------------------------------

            if distance > 0.45:

                text_colour = "white"

            else:

                text_colour = "black"


            ax.text(
                j,
                i,
                text,
                ha="center",
                va="center",
                fontsize=8,
                color=text_colour
            )


    # =========================================================================
    # CELL GRID
    # =========================================================================

    ax.set_xticks(
        np.arange(
            -0.5,
            len(col_order),
            1
        ),
        minor=True
    )

    ax.set_yticks(
        np.arange(
            -0.5,
            len(row_order),
            1
        ),
        minor=True
    )

    ax.grid(
        which="minor",
        color="lightgray",
        linewidth=0.4
    )

    ax.tick_params(
        which="minor",
        bottom=False,
        left=False
    )


    # =========================================================================
    # TITLE
    # =========================================================================

    ax.set_title(
        title,
        fontsize=11.5,
        fontweight="bold",
        pad=4
    )


# =============================================================================
# OPTIONAL REI COLOURBAR
# =============================================================================

# cbar_rei = fig.colorbar(
#     axes[0].images[0],
#     ax=axes[0],
#     orientation="vertical",
#     fraction=0.025,
#     pad=0.02
# )
#
# cbar_rei.set_label(
#     "REI",
#     fontsize=9
# )
#
# cbar_rei.set_ticks(
#     [0, 0.5, 1]
# )
#
# cbar_rei.set_ticklabels(
#     ["Low", "Medium", "High"]
# )


# =============================================================================
# OPTIONAL SEVERITY COLOURBAR
# =============================================================================

# cbar_score = fig.colorbar(
#     score_image,
#     ax=axes[1:],
#     orientation="vertical",
#     fraction=0.025,
#     pad=0.02
# )
#
# cbar_score.set_label(
#     "Severity score",
#     fontsize=9
# )


# =============================================================================
# TABLE AXIS
# =============================================================================
#
# IMPORTANT:
# This axis is now INSIDE the GridSpec.
#
# There is no manually positioned fig.add_axes().
# =============================================================================

table_ax = fig.add_subplot(
    gs[2, :]
)

table_ax.axis(
    "off"
)


# =============================================================================
# HOTSPOT LIST
# =============================================================================

hotspot_codes = [
    code
    for code in row_order
    if code in HOTSPOT_DESCRIPTIONS
]


# =============================================================================
# REGULATORY LIST
# =============================================================================

regulatory_codes = list(
    REGULATORY_DESCRIPTIONS.keys()
)


# =============================================================================
# CREATE TWO COMPACT COLUMNS
# =============================================================================

# Number of rows in each side
n_hotspots = len(
    hotspot_codes
)

n_regulations = len(
    regulatory_codes
)

n_table_rows = max(
    n_hotspots,
    n_regulations
)


# Pad hotspot list
hotspot_codes = (
    hotspot_codes +
    [""] * (
        n_table_rows -
        n_hotspots
    )
)


# Pad regulation list
regulatory_codes = (
    regulatory_codes +
    [""] * (
        n_table_rows -
        n_regulations
    )
)


# =============================================================================
# TABLE CONTENT
# =============================================================================

table_data = []


for i in range(
    n_table_rows
):

    hotspot_code = (
        hotspot_codes[i]
    )

    regulatory_code = (
        regulatory_codes[i]
    )


    # -------------------------------------------------------------------------
    # Hotspot
    # -------------------------------------------------------------------------

    if hotspot_code:

        hotspot_text = (
            f"{hotspot_code} "
            f"({HOTSPOT_DESCRIPTIONS[hotspot_code]})"
        )

    else:

        hotspot_text = ""


    # -------------------------------------------------------------------------
    # Regulation
    # -------------------------------------------------------------------------

    if regulatory_code:

        regulatory_text = (
            f"{regulatory_code} "
            f"{REGULATORY_DESCRIPTIONS[regulatory_code]}"
        )

    else:

        regulatory_text = ""


    table_data.append([
        hotspot_text,
        regulatory_text
    ])


# =============================================================================
# CREATE TABLE
# =============================================================================

table = table_ax.table(
    cellText=table_data,

    colLabels=[
        "SHDB Social Hotspot",
        "Regulatory Framework"
    ],

    cellLoc="left",
    colLoc="left",

    loc="center",

    bbox=[
        0,
        0,
        1,
        1
    ]
)


# =============================================================================
# TABLE FONT
# =============================================================================

table.auto_set_font_size(
    False
)

table.set_fontsize(
    8.5
)


# =============================================================================
# TABLE FORMATTING
# =============================================================================

for (
    row,
    col
), cell in table.get_celld().items():

    # -------------------------------------------------------------------------
    # Borders
    # -------------------------------------------------------------------------

    cell.set_edgecolor(
        "#D9D9D9"
    )

    cell.set_linewidth(
        0.3
    )


    # -------------------------------------------------------------------------
    # VERY COMPACT PADDING
    # -------------------------------------------------------------------------

    cell.PAD = 0.08


    # -------------------------------------------------------------------------
    # HEADER
    # -------------------------------------------------------------------------

    if row == 0:

        cell.set_facecolor(
            "#D9D9D9"
        )

        cell.set_text_props(
            fontweight="bold",
            fontsize=10
        )


    # -------------------------------------------------------------------------
    # BODY
    # -------------------------------------------------------------------------

    else:

        cell.set_facecolor(
            "white"
        )


# =============================================================================
# COLUMN WIDTHS
# =============================================================================

for row in range(
    n_table_rows + 1
):

    table[
        (row, 0)
    ].set_width(
        0.30
    )

    table[
        (row, 1)
    ].set_width(
        0.70
    )


# =============================================================================
# TABLE ROW HEIGHT
# =============================================================================

for cell in table.get_celld().values():

    cell.set_height(
        0.035
    )


# =============================================================================
# SAVE
# =============================================================================

output_file = (
    "SHDB_hotspots_tight_layout.png"
)


fig.savefig(
    output_file,
    dpi=300,
    bbox_inches="tight",
    facecolor="white"
)


# =============================================================================
# DISPLAY
# =============================================================================

plt.show()


print()
print(
    "=" * 70
)
print(
    f"Saved: {output_file}"
)
print(
    "=" * 70
)
print()